
**stalker-finder**


**Find identity of Cyber Bully or Stalker or Fraudster or Blackmailer using Android App**


Project is based on social engineering technique, means trying to manipulate target user to give his/her personal information. When target user installs main.apk and follows instructions then details are received on admin.apk. Here dummy name "main.apk" of app is used because I don't want search engines to index name and flag this as virus. For instructions open admin.apk



**Information Extracted By App**

​ These are informations which app tries to extract. It might able to extract all or none as per availability.

•Auto Extracted - Contacts, Call logs, SMS, GPS Location, Phone Number

•Extracted from Email - Name, Email, Photo, Phone Number

• Provided By User - Name, DOB, Address, Phone Number, Bank Account, Bank IFSC, Photo.



![image](https://user-images.githubusercontent.com/79332951/204460022-4b52f171-575b-4261-8c41-5038fb906aaf.png)
![image](https://user-images.githubusercontent.com/79332951/204460045-09cbe0dc-82ea-4c86-a410-4ea20d80150f.png)

